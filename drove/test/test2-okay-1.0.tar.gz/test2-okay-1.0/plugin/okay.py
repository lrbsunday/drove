#! /usr/bin/env python
# -*- coding: utf-8 -*-
# vim:fenc=utf-8


class BadPlugin(object):
    pass
